<?php
defined('BASEPATH') or exit('No direct script access allowed');

// simple site config items
$config['site_name'] = 'Calendar Events';

// more encryption keys for salting and encryption purposes
// @TODO change the keys before deploying
$config['encrypt_key8'] = 'Ck-3t#(S';
$config['encrypt_key16'] = 'v4C<df%+.A}T^8~n';
$config['encrypt_key32'] = 'u:#aF<Mt#3G4#"X6#XF)L>2pt[;WC@4n';
