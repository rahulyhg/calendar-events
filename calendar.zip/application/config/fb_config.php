<?php
defined('BASEPATH') or exit('No direct script access allowed');

// @TODO make sure the fb website is set to the correct url and change the app_secret
$config['app_id'] = '385804648438360';
$config['app_secret'] = '0c87f39f7c5499fe61a661ad7feb3a66';

